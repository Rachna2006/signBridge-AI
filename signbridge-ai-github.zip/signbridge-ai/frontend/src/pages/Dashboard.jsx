import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Camera, Mic, Siren, GraduationCap, ArrowRight } from "lucide-react";
import { api } from "../services/api.js";

const actions = [
  { to: "/app/translator", label: "Live Sign Translator", text: "Sign to text and speech", icon: Camera },
  { to: "/app/speech", label: "Speech-to-Text", text: "Speak and read the words", icon: Mic },
  { to: "/app/emergency", label: "Emergency Mode", text: "Large quick phrases", icon: Siren },
  { to: "/app/learn", label: "Learn ISL", text: "Practice step by step", icon: GraduationCap },
];

export default function Dashboard() {
  const [recent, setRecent] = useState([]);
  const [backend, setBackend] = useState("checking");

  useEffect(() => {
    api.health().then(() => setBackend("online")).catch(() => setBackend("offline"));
    api.listHistory().then((r) => setRecent(r.slice(0, 5))).catch(() => {});
  }, []);

  return (
    <section className="page fade-up">
      <h1>Welcome to SignBridge AI</h1>
      <p className="lead">Breaking Silence. Connecting People. Pick a tool below to begin.</p>
      <p className={`status ${backend}`} role="status">
        Backend: {backend === "online" ? "Online" : backend === "offline" ? "Offline (start the Flask server)" : "Checking..."}
      </p>
      <div className="grid4">
        {actions.map(({ to, label, text, icon: Icon }) => (
          <Link key={to} to={to} className="card action">
            <span className="icon-chip"><Icon size={22} aria-hidden="true" /></span>
            <h3>{label}</h3>
            <p>{text}</p>
            <span className="more">Open <ArrowRight size={16} aria-hidden="true" /></span>
          </Link>
        ))}
      </div>
      <div className="card">
        <h2>Recent activity</h2>
        {recent.length === 0 ? (
          <p className="muted">Nothing yet. Translations you make will appear here.</p>
        ) : (
          <ul className="plain">
            {recent.map((r) => (
              <li key={r.id}><strong>{r.text}</strong> <span className="muted">({r.kind.replaceAll("_", " ")}, {r.created_at})</span></li>
            ))}
          </ul>
        )}
      </div>
    </section>
  );
}
