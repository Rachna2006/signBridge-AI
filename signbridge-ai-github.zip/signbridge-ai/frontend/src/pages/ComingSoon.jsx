import { Hammer } from "lucide-react";

export default function ComingSoon({ title, stage }) {
  return (
    <section className="page fade-up">
      <h1>{title}</h1>
      <div className="card empty">
        <Hammer size={32} aria-hidden="true" />
        <p><strong>Not built yet.</strong> This module is planned for {stage}. It is not a fake screen: it will be added with real working code.</p>
      </div>
    </section>
  );
}
