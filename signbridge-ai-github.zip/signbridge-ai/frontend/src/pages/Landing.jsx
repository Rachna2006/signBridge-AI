import { Link } from "react-router-dom";
import {
  Hand, Camera, Mic, Siren, GraduationCap, History, Accessibility,
  ArrowRight, ScanLine, Volume2, MessageSquare,
} from "lucide-react";

const features = [
  { icon: Camera, title: "Live Sign Translator", text: "Webcam hand tracking with a trained model for a defined ISL vocabulary." },
  { icon: Mic, title: "Speech-to-Text", text: "Turn spoken words into readable text for two-way conversations." },
  { icon: Siren, title: "Emergency Communication", text: "Large, spoken quick phrases for urgent situations." },
  { icon: GraduationCap, title: "Learn Indian Sign Language", text: "Simple lessons with progress tracking." },
  { icon: History, title: "Translation History", text: "Searchable text history. No video or audio is stored." },
  { icon: Accessibility, title: "Accessible Communication", text: "High contrast, keyboard friendly, large touch targets." },
];

const steps = [
  { icon: Hand, title: "Show Your Sign", text: "Face the camera and sign a supported gesture." },
  { icon: ScanLine, title: "AI Understands Your Gesture", text: "Hand landmarks go to a trained model." },
  { icon: Volume2, title: "Communicate Through Text and Voice", text: "Read the result or hear it spoken." },
];

const hand = [
  [[150,210],[142,170],[140,140],[139,118]],[[170,205],[170,160],[170,128],[170,105]],
  [[190,208],[194,166],[196,136],[197,114]],[[208,220],[218,190],[224,170],[228,154]],
  [[130,232],[112,212],[98,196],[88,182]],
];

function HeroArt() {
  return (
    <div className="hero-art" aria-hidden="true">
      <span className="blob b1" /><span className="blob b2" />
      <div className="scan-card">
        <svg viewBox="0 0 320 300" width="100%">
          <polygon points="170,262 130,232 150,210 170,205 190,208 208,220" fill="#8B5CF6" fillOpacity=".12" stroke="#8B5CF6" strokeWidth="2" />
          {hand.map((f, i) => (
            <g key={i}>
              <polyline points={f.map((p) => p.join(",")).join(" ")} fill="none" stroke="#8B5CF6" strokeWidth="3" strokeLinecap="round" />
              {f.map((p, j) => <circle key={j} cx={p[0]} cy={p[1]} r={j === 3 ? 6 : 4} fill={j === 3 ? "#2DD4BF" : "#25245A"} />)}
            </g>
          ))}
        </svg>
        <span className="scan-line" />
      </div>
      <span className="bubble bub1"><MessageSquare size={18} /> &hellip;</span>
      <span className="bubble bub2"><Volume2 size={18} /> &hellip;</span>
    </div>
  );
}

export default function Landing() {
  return (
    <div className="landing">
      <header className="topbar">
        <a href="#home" className="brand"><span className="brand-mark"><Hand size={20} aria-hidden="true" /></span><span className="brand-name">SignBridge AI</span></a>
        <nav aria-label="Primary" className="topnav">
          <a href="#home">Home</a><a href="#features">Features</a><a href="#how">How It Works</a><a href="#about">About</a>
          <Link to="/app" className="btn primary sm">Get Started</Link>
        </nav>
      </header>

      <section id="home" className="hero fade-up">
        <div>
          <p className="eyebrow">Breaking Silence. Connecting People.</p>
          <h1>Communication Without Boundaries.</h1>
          <p className="lead">Empowering communication through AI-powered Indian Sign Language recognition, speech conversion and accessible technology.</p>
          <div className="cta">
            <Link to="/app/translator" className="btn primary">Start Translating <ArrowRight size={18} aria-hidden="true" /></Link>
            <a href="#features" className="btn secondary">Explore Features</a>
          </div>
          <p className="note">Prototype: recognizes a small trained vocabulary, not full ISL.</p>
        </div>
        <HeroArt />
      </section>

      <section id="how" className="section">
        <h2>How It Works</h2>
        <div className="grid3">
          {steps.map(({ icon: Icon, title, text }, i) => (
            <div className="card step" key={title}>
              <span className="num">{i + 1}</span>
              <span className="icon-chip"><Icon size={24} aria-hidden="true" /></span>
              <h3>{title}</h3><p>{text}</p>
            </div>
          ))}
        </div>
      </section>

      <section id="features" className="section">
        <h2>Features</h2>
        <div className="grid3">
          {features.map(({ icon: Icon, title, text }) => (
            <div className="card feature" key={title}>
              <span className="icon-chip"><Icon size={22} aria-hidden="true" /></span>
              <h3>{title}</h3><p>{text}</p>
            </div>
          ))}
        </div>
      </section>

      <section id="impact" className="section">
        <h2>Who It Can Help</h2>
        <div className="card">
          <ul className="plain impact">
            <li>Deaf and hard-of-hearing individuals in daily conversations.</li>
            <li>Hospitals and clinics, where an interpreter may not be available.</li>
            <li>Educational institutions and public service centres.</li>
          </ul>
          <p className="muted">These are intended use cases of the prototype, not claims of existing deployments.</p>
        </div>
      </section>

      <section id="about" className="section">
        <h2>About</h2>
        <div className="card">
          <p>SignBridge AI is a hackathon prototype that combines MediaPipe hand tracking with a model trained on a small, defined Indian Sign Language vocabulary, plus speech tools and emergency phrases. Continuous signing, grammar and facial expressions are future scope.</p>
        </div>
      </section>
      <footer className="footer">SignBridge AI. Breaking Silence. Connecting People.</footer>
    </div>
  );
}
