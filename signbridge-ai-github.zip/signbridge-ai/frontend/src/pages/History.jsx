import { useEffect, useState } from "react";
import { Search, Trash2 } from "lucide-react";
import { api } from "../services/api.js";

export default function History() {
  const [rows, setRows] = useState([]);
  const [q, setQ] = useState("");
  const [error, setError] = useState("");

  const load = (query = q) =>
    api.listHistory(query).then(setRows).then(() => setError("")).catch(() => setError("Cannot reach the backend. Is the Flask server running?"));

  useEffect(() => {
    const t = setTimeout(() => load(q), 250);
    return () => clearTimeout(t);
  }, [q]);

  const remove = async (id) => { await api.deleteHistory(id); load(); };
  const clearAll = async () => {
    if (window.confirm("Delete all translation history? This cannot be undone.")) {
      await api.clearHistory(); load();
    }
  };
  const addTest = async () => { await api.addHistory({ text: "Developer test record", kind: "test" }); load(); };

  return (
    <section className="page fade-up">
      <h1>Translation History</h1>
      <p className="lead">Only text is stored. Webcam video and audio are never saved.</p>
      <div className="toolbar">
        <label className="search">
          <Search size={18} aria-hidden="true" />
          <span className="sr-only">Search history</span>
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search history" />
        </label>
        <button className="btn secondary" onClick={addTest}>Add developer test record</button>
        <button className="btn danger" onClick={clearAll} disabled={rows.length === 0}>Clear all</button>
      </div>
      {error && <p className="alert" role="alert">{error}</p>}
      <div className="card">
        {rows.length === 0 ? (
          <p className="muted">No records found.</p>
        ) : (
          <ul className="plain history">
            {rows.map((r) => (
              <li key={r.id}>
                <div>
                  <strong>{r.text}</strong>
                  <div className="muted">{r.kind.replaceAll("_", " ")} &middot; {r.created_at} UTC</div>
                </div>
                <button className="icon-btn" onClick={() => remove(r.id)} aria-label={`Delete record: ${r.text}`}>
                  <Trash2 size={18} />
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>
    </section>
  );
}
