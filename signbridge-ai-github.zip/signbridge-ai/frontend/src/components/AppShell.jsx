import { useState } from "react";
import { NavLink, Outlet, Link } from "react-router-dom";
import {
  LayoutDashboard, Camera, Mic, Siren, GraduationCap, History,
  Info, Settings, PanelLeftClose, PanelLeftOpen, Hand,
} from "lucide-react";

const items = [
  { to: "/app", label: "Dashboard", icon: LayoutDashboard, end: true },
  { to: "/app/translator", label: "Live Sign Translator", icon: Camera },
  { to: "/app/speech", label: "Speech-to-Text", icon: Mic },
  { to: "/app/emergency", label: "Emergency Mode", icon: Siren },
  { to: "/app/learn", label: "Learn ISL", icon: GraduationCap },
  { to: "/app/history", label: "Translation History", icon: History },
  { to: "/app/about", label: "About SignBridge AI", icon: Info },
  { to: "/app/settings", label: "Settings", icon: Settings },
];

export default function AppShell() {
  const [collapsed, setCollapsed] = useState(false);
  return (
    <div className="shell">
      <aside className={`sidebar ${collapsed ? "collapsed" : ""}`} aria-label="Main navigation">
        <Link to="/" className="brand" aria-label="SignBridge AI home">
          <span className="brand-mark"><Hand size={20} aria-hidden="true" /></span>
          {!collapsed && <span className="brand-name">SignBridge AI</span>}
        </Link>
        <nav>
          {items.map(({ to, label, icon: Icon, end }) => (
            <NavLink key={to} to={to} end={end} title={label} aria-label={label}
              className={({ isActive }) => `nav-item ${isActive ? "active" : ""}`}>
              <Icon size={20} aria-hidden="true" />
              {!collapsed && <span>{label}</span>}
            </NavLink>
          ))}
        </nav>
        <button className="collapse-btn" onClick={() => setCollapsed(!collapsed)}
          aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"}>
          {collapsed ? <PanelLeftOpen size={20} /> : <PanelLeftClose size={20} />}
          {!collapsed && <span>Collapse</span>}
        </button>
      </aside>
      <main className="content"><Outlet /></main>
    </div>
  );
}
