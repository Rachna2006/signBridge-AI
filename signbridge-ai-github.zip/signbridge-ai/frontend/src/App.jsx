import { Routes, Route } from "react-router-dom";
import Landing from "./pages/Landing.jsx";
import AppShell from "./components/AppShell.jsx";
import Dashboard from "./pages/Dashboard.jsx";
import History from "./pages/History.jsx";
import ComingSoon from "./pages/ComingSoon.jsx";

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Landing />} />
      <Route path="/app" element={<AppShell />}>
        <Route index element={<Dashboard />} />
        <Route path="translator" element={<ComingSoon title="Live Sign Translator" stage="Stages 3 to 5" />} />
        <Route path="speech" element={<ComingSoon title="Speech-to-Text" stage="Stage 6" />} />
        <Route path="emergency" element={<ComingSoon title="Emergency Mode" stage="Stage 7" />} />
        <Route path="learn" element={<ComingSoon title="Learn ISL" stage="Stage 8" />} />
        <Route path="history" element={<History />} />
        <Route path="about" element={<ComingSoon title="About SignBridge AI" stage="Stage 9" />} />
        <Route path="settings" element={<ComingSoon title="Settings" stage="Stage 9" />} />
      </Route>
    </Routes>
  );
}
