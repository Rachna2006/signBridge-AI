// All backend calls live here, so pages stay clean.
// Locally, VITE_API_URL is empty and Vite proxies /api to Flask.
// On Render, VITE_API_URL is the backend URL (for example https://signbridge-api.onrender.com).
const BASE = (import.meta.env.VITE_API_URL || "").replace(/\/$/, "");

async function request(path, options = {}) {
  const res = await fetch(`${BASE}/api${path}`, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });
  if (!res.ok) throw new Error(`Request failed (${res.status})`);
  return res.json();
}

export const api = {
  health: () => request("/health"),
  listHistory: (q = "") => request(`/history/?q=${encodeURIComponent(q)}`),
  addHistory: (item) => request("/history/", { method: "POST", body: JSON.stringify(item) }),
  deleteHistory: (id) => request(`/history/${id}`, { method: "DELETE" }),
  clearHistory: () => request("/history/", { method: "DELETE" }),
};
