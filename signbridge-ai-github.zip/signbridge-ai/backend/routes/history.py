from flask import Blueprint, jsonify, request
from db import get_conn

bp = Blueprint("history", __name__, url_prefix="/api/history")
ALLOWED_KINDS = ("sign_to_text", "speech_to_text", "emergency", "test")


@bp.get("/", strict_slashes=False)
def list_history():
    q = request.args.get("q", "").strip()
    conn = get_conn()
    if q:
        like = f"%{q}%"
        rows = conn.execute(
            "SELECT * FROM history WHERE text LIKE ? OR gesture LIKE ? ORDER BY id DESC",
            (like, like),
        ).fetchall()
    else:
        rows = conn.execute("SELECT * FROM history ORDER BY id DESC LIMIT 200").fetchall()
    conn.close()
    return jsonify([dict(r) for r in rows])


@bp.post("/", strict_slashes=False)
def add_history():
    data = request.get_json(silent=True) or {}
    text = (data.get("text") or "").strip()
    kind = data.get("kind")
    gesture = (data.get("gesture") or "").strip() or None
    if not text or kind not in ALLOWED_KINDS:
        return jsonify(error="text and a valid kind are required"), 400
    conn = get_conn()
    with conn:
        cur = conn.execute(
            "INSERT INTO history (gesture, text, kind) VALUES (?, ?, ?)",
            (gesture, text[:500], kind),
        )
    new_id = cur.lastrowid
    conn.close()
    return jsonify(id=new_id), 201


@bp.delete("/<int:item_id>")
def delete_one(item_id):
    conn = get_conn()
    with conn:
        conn.execute("DELETE FROM history WHERE id = ?", (item_id,))
    conn.close()
    return jsonify(ok=True)


@bp.delete("/", strict_slashes=False)
def clear_all():
    conn = get_conn()
    with conn:
        conn.execute("DELETE FROM history")
    conn.close()
    return jsonify(ok=True)
