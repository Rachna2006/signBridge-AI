import os
from flask import Flask, jsonify
from flask_cors import CORS
from db import init_db
from routes.history import bp as history_bp


def create_app():
    app = Flask(__name__)

    # Allowed websites that may call this API.
    # Locally: the Vite dev server. On Render: set FRONTEND_ORIGIN to your frontend URL.
    origins = ["http://localhost:5173", "http://127.0.0.1:5173"]
    extra = os.environ.get("FRONTEND_ORIGIN", "")
    origins += [o.strip().rstrip("/") for o in extra.split(",") if o.strip()]
    CORS(app, resources={r"/api/*": {"origins": origins}})

    init_db()
    app.register_blueprint(history_bp)

    @app.get("/api/health")
    def health():
        return jsonify(status="ok", model_loaded=False)

    return app


# Gunicorn (used on Render) looks for this "app" object.
app = create_app()

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)
